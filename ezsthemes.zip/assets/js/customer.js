$('.customer-charactor__box-mobile').click(function () {
    $(this).parents('.customer-charactor__box-detail').addClass('active')
})